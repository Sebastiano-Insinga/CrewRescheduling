[
   {
      "id_trip": 22588,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22964,
      "locomotive": "canceled"
   },
   {
      "id_trip": 23522,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23197,
      "locomotive": "canceled"
   },
   {
      "id_trip": 23214,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23118,
      "locomotive": "canceled"
   },
   {
      "id_trip": 23191,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22949,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22901,
      "locomotive": "canceled"
   },
   {
      "id_trip": 22867,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22844,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23383,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23249,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23367,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23064,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23206,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22653,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22585,
      "locomotive": "canceled"
   },
   {
      "id_trip": 22862,
      "locomotive": 22569,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22608,
      "locomotive": "canceled"
   },
   {
      "id_trip": 23370,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22859,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23217,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22721,
      "locomotive": "canceled"
   },
   {
      "id_trip": 22922,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23209,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23083,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22876,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23306,
      "locomotive": "canceled"
   },
   {
      "id_trip": 22655,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22878,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23211,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22880,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22870,
      "locomotive": "canceled"
   },
   {
      "id_trip": 22677,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23034,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22657,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22970,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22873,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23475,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22760,
      "locomotive": "canceled"
   },
   {
      "id_trip": 23163,
      "locomotive": 22569,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22679,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22659,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22829,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23106,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22681,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23315,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23145,
      "locomotive": 22569,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23160,
      "locomotive": "canceled"
   },
   {
      "id_trip": 22715,
      "locomotive": "canceled"
   },
   {
      "id_trip": 23478,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23027,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23127,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23480,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23169,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23317,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23482,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23029,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22630,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23171,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23319,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23173,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23031,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23052,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23321,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22647,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23506,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22898,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22892,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23432,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23124,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22832,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22733,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23054,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22913,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23380,
      "locomotive": 22569,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22973,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22987,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23056,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23485,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22591,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22834,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23458,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23058,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22989,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22991,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22836,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23151,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22838,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22934,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22730,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23176,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22736,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22718,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23491,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22769,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23067,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23121,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23446,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22967,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23157,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23500,
      "locomotive": 22569,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23452,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23148,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23512,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22619,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22621,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23141,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22702,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23464,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22742,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22623,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23389,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23466,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22625,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23265,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23332,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23391,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23468,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23267,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22627,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23393,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23470,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23269,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22755,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22757,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23271,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23000,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22594,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22748,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23472,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23273,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23386,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22750,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23327,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23329,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22752,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23494,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23252,
      "locomotive": 22569,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22674,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22979,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23109,
      "locomotive": 22567,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23226,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22952,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22724,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22789,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23347,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22954,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22780,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23414,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22981,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23040,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22956,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23342,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23255,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22958,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23344,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22847,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23258,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23011,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22931,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23300,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22690,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23525,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22809,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23133,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23203,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23024,
      "locomotive": 22563,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23136,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23229,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23138,
      "locomotive": 22560,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22668,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22693,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23115,
      "locomotive": 22565,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23080,
      "locomotive": 22558,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   }
]