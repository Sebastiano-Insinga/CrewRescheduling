[
   {
      "id_trip": 22686,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23028,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22666,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22842,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22729,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22569,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22784,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22925,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22979,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22781,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22853,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22927,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22855,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22929,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22857,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22597,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22952,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22590,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22593,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22935,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22836,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22937,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 22949,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23009,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22912,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22683,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22645,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22967,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 22902,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22932,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22617,
      "locomotive": 22550,
      "maintenance_at_departure": "true",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22833,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22720,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 22787,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22789,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22791,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22630,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22793,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22795,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 22632,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22640,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22634,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 22677,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22701,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22642,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22973,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22623,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22775,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22946,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22625,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22627,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22767,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22747,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22695,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22663,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22976,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 23019,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22985,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22815,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22707,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22961,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22801,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22710,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22818,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23006,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22713,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22698,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22715,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22820,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22717,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23025,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22822,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22863,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22824,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22865,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22867,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 22830,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22958,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22827,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22572,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22994,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22955,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23031,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22750,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22890,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22738,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "true"
   },
   {
      "id_trip": 22988,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22620,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22943,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22892,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22884,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22798,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22895,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22756,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22654,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22887,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22898,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22764,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22726,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22964,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22759,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22905,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22656,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22907,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22761,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22909,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23041,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22658,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22991,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22778,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22660,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22860,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22637,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22723,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22689,
      "locomotive": 22552,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23034,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23036,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22614,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23038,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22578,
      "locomotive": 22562,
      "maintenance_at_departure": "true",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22648,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23022,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22940,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22915,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22651,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22870,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22741,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22580,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22997,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23012,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22582,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22872,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22982,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22584,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23014,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23016,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22874,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22876,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22970,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22735,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22704,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22744,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23000,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22587,
      "locomotive": 22555,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22603,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22605,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22607,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22918,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22609,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22804,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22920,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22806,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22611,
      "locomotive": 22554,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22922,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22808,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22770,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22772,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22810,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22575,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22812,
      "locomotive": 22561,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22845,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22847,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 23003,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22732,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22879,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22881,
      "locomotive": 22562,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22839,
      "locomotive": 22551,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22850,
      "locomotive": 22553,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22669,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22753,
      "locomotive": 22564,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22672,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22674,
      "locomotive": 22550,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22680,
      "locomotive": 22559,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22692,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   },
   {
      "id_trip": 22600,
      "locomotive": 22556,
      "maintenance_at_departure": "false",
      "maintenance_at_destination": "false"
   }
]